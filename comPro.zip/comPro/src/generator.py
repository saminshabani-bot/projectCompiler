from grammer.MiniCVisitor import MiniCVisitor
from grammer.MiniCParser import MiniCParser


class CodeGenerator(MiniCVisitor):
    def __init__(self):
        self.indent = 0

    def tab(self):
        return '    ' * self.indent

    def visitProgram(self, ctx: MiniCParser.ProgramContext):
        return '\n\n'.join([self.visit(child) for child in ctx.children[:-1]])

    def visitFunctionDefinition(self, ctx: MiniCParser.FunctionDefinitionContext):
        ret_type = ctx.typeSpecifier().getText()
        name = ctx.Identifier().getText()
        params = self.visit(ctx.parameterList()) if ctx.parameterList() else ''
        body = self.visit(ctx.compoundStatement())
        return f"{ret_type} {name}({params}) {body}"

    def visitParameterList(self, ctx: MiniCParser.ParameterListContext):
        return ', '.join([self.visit(param) for param in ctx.parameter()])

    def visitParameter(self, ctx: MiniCParser.ParameterContext):
        return f"{ctx.typeSpecifier().getText()} {ctx.Identifier().getText()}"

    def visitCompoundStatement(self, ctx: MiniCParser.CompoundStatementContext):
        self.indent += 1
        lines = []
        for child in ctx.blockItem():
            if isinstance(child, str):  # کد مرده دستی
                lines.append(self.tab() + child)
            else:
                lines.append(self.visit(child))
        self.indent -= 1
        return f"{{\n" + '\n'.join(lines) + f"\n{self.tab()}}}"

    def visitDeclaration(self, ctx: MiniCParser.DeclarationContext):
        typename = ctx.typeSpecifier().getText()
        decls = ', '.join([self.visit(d) for d in ctx.declaratorList().initDeclarator()])
        return f"{self.tab()}{typename} {decls};"

    def visitInitDeclarator(self, ctx: MiniCParser.InitDeclaratorContext):
        name = ctx.Identifier().getText()
        if ctx.expression():
            expr = self.visit(ctx.expression())
            return f"{name} = {expr}"
        return name

    def visitStatement(self, ctx: MiniCParser.StatementContext):
        return self.visit(ctx.getChild(0))

    def visitExpressionStatement(self, ctx: MiniCParser.ExpressionStatementContext):
        if ctx.expression():
            return f"{self.tab()}{self.visit(ctx.expression())};"
        return f"{self.tab()};"

    def visitSelectionStatement(self, ctx: MiniCParser.SelectionStatementContext):
        cond = self.visit(ctx.expression())
        then_stmt = self.visit(ctx.statement(0))
        else_stmt = self.visit(ctx.statement(1)) if ctx.ELSE() else ''
        if else_stmt:
            return f"{self.tab()}if ({cond}) {then_stmt} else {else_stmt}"
        return f"{self.tab()}if ({cond}) {then_stmt}"

    def visitIterationStatement(self, ctx: MiniCParser.IterationStatementContext):
        if ctx.WHILE():
            cond = self.visit(ctx.expression(0))
            body = self.visit(ctx.statement())
            return f"{self.tab()}while ({cond}) {body}"
        elif ctx.FOR():
            init = self.visit(ctx.expression(0)) if ctx.expression(0) else ''
            cond = self.visit(ctx.expression(1)) if ctx.expression(1) else ''
            post = self.visit(ctx.expression(2)) if ctx.expression(2) else ''
            body = self.visit(ctx.statement())
            return f"{self.tab()}for ({init}; {cond}; {post}) {body}"

    def visitJumpStatement(self, ctx: MiniCParser.JumpStatementContext):
        if ctx.expression():
            return f"{self.tab()}return {self.visit(ctx.expression())};"
        return f"{self.tab()}return;"

    def visitAssignmentExpression(self, ctx: MiniCParser.AssignmentExpressionContext):
        if ctx.getChildCount() == 3:
            left = ctx.getChild(0).getText()
            right = self.visit(ctx.getChild(2))
            return f"{left} = {right}"
        return self.visit(ctx.getChild(0))

    def visitAdditiveExpression(self, ctx: MiniCParser.AdditiveExpressionContext):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.getChild(0))
        left = self.visit(ctx.getChild(0))
        op = ctx.getChild(1).getText()
        right = self.visit(ctx.getChild(2))
        return f"{left} {op} {right}"

    def visitMultiplicativeExpression(self, ctx: MiniCParser.MultiplicativeExpressionContext):
        if ctx.getChildCount() == 1:
            return self.visit(ctx.getChild(0))
        left = self.visit(ctx.getChild(0))
        op = ctx.getChild(1).getText()
        right = self.visit(ctx.getChild(2))
        return f"{left} {op} {right}"

    def visitPrimaryExpression(self, ctx: MiniCParser.PrimaryExpressionContext):
        if ctx.IntegerConstant():
            return ctx.IntegerConstant().getText()
        elif ctx.Identifier():
            return ctx.Identifier().getText()
        elif ctx.functionCall():
            return self.visit(ctx.functionCall())
        elif ctx.expression():
            return f"({self.visit(ctx.expression())})"
        return ''

    def visitFunctionCall(self, ctx: MiniCParser.FunctionCallContext):
        name = ctx.Identifier().getText()
        args = self.visit(ctx.argumentExpressionList()) if ctx.argumentExpressionList() else ''
        return f"{name}({args})"

    def visitArgumentExpressionList(self, ctx: MiniCParser.ArgumentExpressionListContext):
        return ', '.join([self.visit(expr) for expr in ctx.expression()])


