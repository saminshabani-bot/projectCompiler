import sys

from antlr4 import *
from grammer.MiniCLexer import MiniCLexer
from grammer.MiniCParser import MiniCParser
from src.generator import CodeGenerator
from src.obfuscator import ObfuscatorVisitor
def main(input_file, output_file):
    input_stream = FileStream(input_file)
    lexer = MiniCLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = MiniCParser(stream)
    tree = parser.program()

    obfuscator = ObfuscatorVisitor()
    obfuscated_ast = obfuscator.visit(tree)

    code_generator = CodeGenerator()
    code = code_generator.visit(obfuscated_ast)

    with open(output_file, 'w') as f:
        f.write(code)

if __name__ == '__main__':
    main('input.mc', 'output.mc')

