import random
from grammer.MiniCVisitor import MiniCVisitor
from grammer.MiniCParser import MiniCParser
from antlr4 import *

class ObfuscatorVisitor(MiniCVisitor):
    def __init__(self):
        self.var_counter = 1
        self.func_counter = 1
        self.var_map = {}
        self.func_map = {}
        self.dead_counter = 1

    def get_new_var_name(self):
        name = f"var{self.var_counter}"
        self.var_counter += 1
        return name

    def get_new_func_name(self):
        name = f"fxz{self.func_counter}"
        self.func_counter += 1
        return name

    def visitFunctionDefinition(self, ctx: MiniCParser.FunctionDefinitionContext):
        def visitFunctionDefinition(self, ctx: MiniCParser.FunctionDefinitionContext):
            func_name = ctx.Identifier().getText()

            # فقط برای main
            if func_name == "main":
                # بازنویسی بدنه
                statements = [stmt for stmt in ctx.compoundStatement().blockItem()]
                new_block = self.build_flattened_control_flow(statements)
                ctx.compoundStatement().children = new_block
                return ctx

            # تابع‌های دیگر بدون flatten فقط obfuscate می‌شوند
            if func_name not in self.func_map:
                new_name = self.get_new_func_name()
                self.func_map[func_name] = new_name

            self.visit(ctx.compoundStatement())
            return ctx

    def visitInitDeclarator(self, ctx: MiniCParser.InitDeclaratorContext):
        original_name = ctx.Identifier().getText()
        if original_name not in self.var_map:
            new_name = self.get_new_var_name()
            self.var_map[original_name] = new_name
        if ctx.expression():
            self.visit(ctx.expression())
        return ctx

    def visitPrimaryExpression(self, ctx: MiniCParser.PrimaryExpressionContext):
        if ctx.Identifier():
            name = ctx.Identifier().getText()
            if name in self.var_map:
                ctx.children[0].symbol.text = self.var_map[name]
            elif name in self.func_map:
                ctx.children[0].symbol.text = self.func_map[name]
        return ctx

    def visitFunctionCall(self, ctx: MiniCParser.FunctionCallContext):
        name = ctx.Identifier().getText()
        if name in self.func_map:
            ctx.children[0].symbol.text = self.func_map[name]
        if ctx.argumentExpressionList():
            self.visit(ctx.argumentExpressionList())
        return ctx

    def visitAssignmentExpression(self, ctx: MiniCParser.AssignmentExpressionContext):
        if ctx.getChildCount() == 3:  # ID = expr
            name = ctx.getChild(0).getText()
            if name in self.var_map:
                ctx.children[0].symbol.text = self.var_map[name]
        self.visitChildren(ctx)
        return ctx

    def get_dead_code_statement(self):
        var_name = f"useless{self.dead_counter}"
        value = random.randint(1000, 9999)
        self.dead_counter += 1
        return f"int {var_name} = {value};"

    def visitCompoundStatement(self, ctx: MiniCParser.CompoundStatementContext):
        # بازدید از بچه‌های اصلی
        self.genericVisit(ctx)

        # فقط در بدنه‌های توابع و بلوک‌ها کد مرده اضافه می‌کنیم
        if ctx.blockItem():
            new_code = self.get_dead_code_statement()
            fake_decl = self._create_fake_decl(new_code)
            ctx.children.insert(1, fake_decl)  # بعد از { اضافه می‌شود
        return ctx

    def _create_fake_decl(self, code_text):
        """
        ساخت یک گره AST جعلی برای کد مرده. در واقع ساده‌ترین راه تزریق متن خام به مرحله تولید کد است.
        چون AST ساخت‌یافته پیچیده است، فعلاً در مرحله تولید کد، این متغیر را دستی اضافه می‌کنیم.
        """
        return code_text  # در مرحله تولید کد، اگر string پیدا شد، مستقیماً چاپ می‌شود

    def build_flattened_control_flow(self, statements):
        switch_cases = []
        selector_init = "int selector = 1;"

        # map case numbers to real statements
        for i, stmt in enumerate(statements):
            case_num = i + 1
            next_selector = case_num + 1 if i + 1 < len(statements) else 0

            switch_case = [
                f"case {case_num}:",
                self.statement_to_string(stmt),
                f"    selector = {next_selector};",
                "    break;"
            ]
            switch_cases.extend(switch_case)

        # نهایی‌سازی switch و while
        switch_block = ["switch(selector) {"] + switch_cases + ["}"]
        while_block = ["while (selector > 0) {"] + switch_block + ["}"]

        return ["{", selector_init] + while_block + ["}"]

    def statement_to_string(self, stmt):
        if hasattr(stmt, 'getText'):
            return "    " + stmt.getText()
        if isinstance(stmt, str):
            return "    " + stmt
        return "    // unsupported"

