# Generated from MiniC.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,23,166,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,1,0,1,0,5,0,37,8,0,10,0,12,0,40,9,
        0,1,0,1,0,1,1,1,1,1,1,1,1,3,1,48,8,1,1,1,1,1,1,1,1,2,1,2,1,2,5,2,
        56,8,2,10,2,12,2,59,9,2,1,3,1,3,1,3,1,4,1,4,1,4,1,4,3,4,68,8,4,1,
        4,1,4,1,5,1,5,1,6,1,6,1,6,5,6,77,8,6,10,6,12,6,80,9,6,1,6,1,6,1,
        7,1,7,1,7,1,7,1,7,3,7,89,8,7,1,8,1,8,1,8,1,8,1,8,1,8,1,8,3,8,98,
        8,8,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,3,9,109,8,9,1,9,1,9,3,9,
        113,8,9,1,9,1,9,3,9,117,8,9,1,9,1,9,3,9,121,8,9,1,10,1,10,3,10,125,
        8,10,1,10,1,10,1,11,3,11,130,8,11,1,11,1,11,1,12,1,12,1,13,1,13,
        1,13,1,13,3,13,140,8,13,1,14,1,14,1,14,5,14,145,8,14,10,14,12,14,
        148,9,14,1,15,1,15,1,15,5,15,153,8,15,10,15,12,15,156,9,15,1,16,
        1,16,1,16,1,16,1,16,1,16,3,16,164,8,16,1,16,0,0,17,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,32,0,3,1,0,6,8,1,0,16,17,1,0,18,19,
        171,0,38,1,0,0,0,2,43,1,0,0,0,4,52,1,0,0,0,6,60,1,0,0,0,8,63,1,0,
        0,0,10,71,1,0,0,0,12,73,1,0,0,0,14,88,1,0,0,0,16,90,1,0,0,0,18,120,
        1,0,0,0,20,122,1,0,0,0,22,129,1,0,0,0,24,133,1,0,0,0,26,139,1,0,
        0,0,28,141,1,0,0,0,30,149,1,0,0,0,32,163,1,0,0,0,34,37,3,2,1,0,35,
        37,3,8,4,0,36,34,1,0,0,0,36,35,1,0,0,0,37,40,1,0,0,0,38,36,1,0,0,
        0,38,39,1,0,0,0,39,41,1,0,0,0,40,38,1,0,0,0,41,42,5,0,0,1,42,1,1,
        0,0,0,43,44,3,10,5,0,44,45,5,20,0,0,45,47,5,1,0,0,46,48,3,4,2,0,
        47,46,1,0,0,0,47,48,1,0,0,0,48,49,1,0,0,0,49,50,5,2,0,0,50,51,3,
        12,6,0,51,3,1,0,0,0,52,57,3,6,3,0,53,54,5,3,0,0,54,56,3,6,3,0,55,
        53,1,0,0,0,56,59,1,0,0,0,57,55,1,0,0,0,57,58,1,0,0,0,58,5,1,0,0,
        0,59,57,1,0,0,0,60,61,3,10,5,0,61,62,5,20,0,0,62,7,1,0,0,0,63,64,
        3,10,5,0,64,67,5,20,0,0,65,66,5,4,0,0,66,68,3,24,12,0,67,65,1,0,
        0,0,67,68,1,0,0,0,68,69,1,0,0,0,69,70,5,5,0,0,70,9,1,0,0,0,71,72,
        7,0,0,0,72,11,1,0,0,0,73,78,5,9,0,0,74,77,3,14,7,0,75,77,3,8,4,0,
        76,74,1,0,0,0,76,75,1,0,0,0,77,80,1,0,0,0,78,76,1,0,0,0,78,79,1,
        0,0,0,79,81,1,0,0,0,80,78,1,0,0,0,81,82,5,10,0,0,82,13,1,0,0,0,83,
        89,3,22,11,0,84,89,3,12,6,0,85,89,3,16,8,0,86,89,3,18,9,0,87,89,
        3,20,10,0,88,83,1,0,0,0,88,84,1,0,0,0,88,85,1,0,0,0,88,86,1,0,0,
        0,88,87,1,0,0,0,89,15,1,0,0,0,90,91,5,11,0,0,91,92,5,1,0,0,92,93,
        3,24,12,0,93,94,5,2,0,0,94,97,3,14,7,0,95,96,5,12,0,0,96,98,3,14,
        7,0,97,95,1,0,0,0,97,98,1,0,0,0,98,17,1,0,0,0,99,100,5,13,0,0,100,
        101,5,1,0,0,101,102,3,24,12,0,102,103,5,2,0,0,103,104,3,14,7,0,104,
        121,1,0,0,0,105,106,5,14,0,0,106,108,5,1,0,0,107,109,3,24,12,0,108,
        107,1,0,0,0,108,109,1,0,0,0,109,110,1,0,0,0,110,112,5,5,0,0,111,
        113,3,24,12,0,112,111,1,0,0,0,112,113,1,0,0,0,113,114,1,0,0,0,114,
        116,5,5,0,0,115,117,3,24,12,0,116,115,1,0,0,0,116,117,1,0,0,0,117,
        118,1,0,0,0,118,119,5,2,0,0,119,121,3,14,7,0,120,99,1,0,0,0,120,
        105,1,0,0,0,121,19,1,0,0,0,122,124,5,15,0,0,123,125,3,24,12,0,124,
        123,1,0,0,0,124,125,1,0,0,0,125,126,1,0,0,0,126,127,5,5,0,0,127,
        21,1,0,0,0,128,130,3,24,12,0,129,128,1,0,0,0,129,130,1,0,0,0,130,
        131,1,0,0,0,131,132,5,5,0,0,132,23,1,0,0,0,133,134,3,26,13,0,134,
        25,1,0,0,0,135,136,5,20,0,0,136,137,5,4,0,0,137,140,3,28,14,0,138,
        140,3,28,14,0,139,135,1,0,0,0,139,138,1,0,0,0,140,27,1,0,0,0,141,
        146,3,30,15,0,142,143,7,1,0,0,143,145,3,30,15,0,144,142,1,0,0,0,
        145,148,1,0,0,0,146,144,1,0,0,0,146,147,1,0,0,0,147,29,1,0,0,0,148,
        146,1,0,0,0,149,154,3,32,16,0,150,151,7,2,0,0,151,153,3,32,16,0,
        152,150,1,0,0,0,153,156,1,0,0,0,154,152,1,0,0,0,154,155,1,0,0,0,
        155,31,1,0,0,0,156,154,1,0,0,0,157,164,5,20,0,0,158,164,5,21,0,0,
        159,160,5,1,0,0,160,161,3,24,12,0,161,162,5,2,0,0,162,164,1,0,0,
        0,163,157,1,0,0,0,163,158,1,0,0,0,163,159,1,0,0,0,164,33,1,0,0,0,
        19,36,38,47,57,67,76,78,88,97,108,112,116,120,124,129,139,146,154,
        163
    ]

class MiniCParser ( Parser ):

    grammarFileName = "MiniC.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "','", "'='", "';'", "'int'", 
                     "'char'", "'bool'", "'{'", "'}'", "'if'", "'else'", 
                     "'while'", "'for'", "'return'", "'+'", "'-'", "'*'", 
                     "'/'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "ID", "INT", "WS", "COMMENT" ]

    RULE_program = 0
    RULE_functionDefinition = 1
    RULE_parameterList = 2
    RULE_parameter = 3
    RULE_declaration = 4
    RULE_type = 5
    RULE_compoundStatement = 6
    RULE_statement = 7
    RULE_selectionStatement = 8
    RULE_iterationStatement = 9
    RULE_returnStatement = 10
    RULE_expressionStatement = 11
    RULE_expression = 12
    RULE_assignmentExpression = 13
    RULE_additiveExpression = 14
    RULE_multiplicativeExpression = 15
    RULE_primaryExpression = 16

    ruleNames =  [ "program", "functionDefinition", "parameterList", "parameter", 
                   "declaration", "type", "compoundStatement", "statement", 
                   "selectionStatement", "iterationStatement", "returnStatement", 
                   "expressionStatement", "expression", "assignmentExpression", 
                   "additiveExpression", "multiplicativeExpression", "primaryExpression" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    ID=20
    INT=21
    WS=22
    COMMENT=23

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(MiniCParser.EOF, 0)

        def functionDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.FunctionDefinitionContext)
            else:
                return self.getTypedRuleContext(MiniCParser.FunctionDefinitionContext,i)


        def declaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.DeclarationContext)
            else:
                return self.getTypedRuleContext(MiniCParser.DeclarationContext,i)


        def getRuleIndex(self):
            return MiniCParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = MiniCParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 38
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 448) != 0):
                self.state = 36
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 34
                    self.functionDefinition()
                    pass

                elif la_ == 2:
                    self.state = 35
                    self.declaration()
                    pass


                self.state = 40
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 41
            self.match(MiniCParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(MiniCParser.TypeContext,0)


        def ID(self):
            return self.getToken(MiniCParser.ID, 0)

        def compoundStatement(self):
            return self.getTypedRuleContext(MiniCParser.CompoundStatementContext,0)


        def parameterList(self):
            return self.getTypedRuleContext(MiniCParser.ParameterListContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_functionDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionDefinition" ):
                listener.enterFunctionDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionDefinition" ):
                listener.exitFunctionDefinition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionDefinition" ):
                return visitor.visitFunctionDefinition(self)
            else:
                return visitor.visitChildren(self)




    def functionDefinition(self):

        localctx = MiniCParser.FunctionDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_functionDefinition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 43
            self.type_()
            self.state = 44
            self.match(MiniCParser.ID)
            self.state = 45
            self.match(MiniCParser.T__0)
            self.state = 47
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 448) != 0):
                self.state = 46
                self.parameterList()


            self.state = 49
            self.match(MiniCParser.T__1)
            self.state = 50
            self.compoundStatement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.ParameterContext)
            else:
                return self.getTypedRuleContext(MiniCParser.ParameterContext,i)


        def getRuleIndex(self):
            return MiniCParser.RULE_parameterList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameterList" ):
                listener.enterParameterList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameterList" ):
                listener.exitParameterList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameterList" ):
                return visitor.visitParameterList(self)
            else:
                return visitor.visitChildren(self)




    def parameterList(self):

        localctx = MiniCParser.ParameterListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_parameterList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 52
            self.parameter()
            self.state = 57
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==3:
                self.state = 53
                self.match(MiniCParser.T__2)
                self.state = 54
                self.parameter()
                self.state = 59
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(MiniCParser.TypeContext,0)


        def ID(self):
            return self.getToken(MiniCParser.ID, 0)

        def getRuleIndex(self):
            return MiniCParser.RULE_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameter" ):
                listener.enterParameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameter" ):
                listener.exitParameter(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameter" ):
                return visitor.visitParameter(self)
            else:
                return visitor.visitChildren(self)




    def parameter(self):

        localctx = MiniCParser.ParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_parameter)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 60
            self.type_()
            self.state = 61
            self.match(MiniCParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(MiniCParser.TypeContext,0)


        def ID(self):
            return self.getToken(MiniCParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(MiniCParser.ExpressionContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_declaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaration" ):
                listener.enterDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaration" ):
                listener.exitDeclaration(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaration" ):
                return visitor.visitDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def declaration(self):

        localctx = MiniCParser.DeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_declaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 63
            self.type_()
            self.state = 64
            self.match(MiniCParser.ID)
            self.state = 67
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==4:
                self.state = 65
                self.match(MiniCParser.T__3)
                self.state = 66
                self.expression()


            self.state = 69
            self.match(MiniCParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MiniCParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitType" ):
                return visitor.visitType(self)
            else:
                return visitor.visitChildren(self)




    def type_(self):

        localctx = MiniCParser.TypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 71
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 448) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompoundStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.StatementContext)
            else:
                return self.getTypedRuleContext(MiniCParser.StatementContext,i)


        def declaration(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.DeclarationContext)
            else:
                return self.getTypedRuleContext(MiniCParser.DeclarationContext,i)


        def getRuleIndex(self):
            return MiniCParser.RULE_compoundStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompoundStatement" ):
                listener.enterCompoundStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompoundStatement" ):
                listener.exitCompoundStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCompoundStatement" ):
                return visitor.visitCompoundStatement(self)
            else:
                return visitor.visitChildren(self)




    def compoundStatement(self):

        localctx = MiniCParser.CompoundStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_compoundStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 73
            self.match(MiniCParser.T__8)
            self.state = 78
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 3206114) != 0):
                self.state = 76
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [1, 5, 9, 11, 13, 14, 15, 20, 21]:
                    self.state = 74
                    self.statement()
                    pass
                elif token in [6, 7, 8]:
                    self.state = 75
                    self.declaration()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 80
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 81
            self.match(MiniCParser.T__9)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expressionStatement(self):
            return self.getTypedRuleContext(MiniCParser.ExpressionStatementContext,0)


        def compoundStatement(self):
            return self.getTypedRuleContext(MiniCParser.CompoundStatementContext,0)


        def selectionStatement(self):
            return self.getTypedRuleContext(MiniCParser.SelectionStatementContext,0)


        def iterationStatement(self):
            return self.getTypedRuleContext(MiniCParser.IterationStatementContext,0)


        def returnStatement(self):
            return self.getTypedRuleContext(MiniCParser.ReturnStatementContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = MiniCParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_statement)
        try:
            self.state = 88
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 5, 20, 21]:
                self.enterOuterAlt(localctx, 1)
                self.state = 83
                self.expressionStatement()
                pass
            elif token in [9]:
                self.enterOuterAlt(localctx, 2)
                self.state = 84
                self.compoundStatement()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 3)
                self.state = 85
                self.selectionStatement()
                pass
            elif token in [13, 14]:
                self.enterOuterAlt(localctx, 4)
                self.state = 86
                self.iterationStatement()
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 5)
                self.state = 87
                self.returnStatement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SelectionStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(MiniCParser.ExpressionContext,0)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.StatementContext)
            else:
                return self.getTypedRuleContext(MiniCParser.StatementContext,i)


        def getRuleIndex(self):
            return MiniCParser.RULE_selectionStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSelectionStatement" ):
                listener.enterSelectionStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSelectionStatement" ):
                listener.exitSelectionStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSelectionStatement" ):
                return visitor.visitSelectionStatement(self)
            else:
                return visitor.visitChildren(self)




    def selectionStatement(self):

        localctx = MiniCParser.SelectionStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_selectionStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 90
            self.match(MiniCParser.T__10)
            self.state = 91
            self.match(MiniCParser.T__0)
            self.state = 92
            self.expression()
            self.state = 93
            self.match(MiniCParser.T__1)
            self.state = 94
            self.statement()
            self.state = 97
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.state = 95
                self.match(MiniCParser.T__11)
                self.state = 96
                self.statement()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IterationStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MiniCParser.ExpressionContext,i)


        def statement(self):
            return self.getTypedRuleContext(MiniCParser.StatementContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_iterationStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIterationStatement" ):
                listener.enterIterationStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIterationStatement" ):
                listener.exitIterationStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIterationStatement" ):
                return visitor.visitIterationStatement(self)
            else:
                return visitor.visitChildren(self)




    def iterationStatement(self):

        localctx = MiniCParser.IterationStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_iterationStatement)
        self._la = 0 # Token type
        try:
            self.state = 120
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [13]:
                self.enterOuterAlt(localctx, 1)
                self.state = 99
                self.match(MiniCParser.T__12)
                self.state = 100
                self.match(MiniCParser.T__0)
                self.state = 101
                self.expression()
                self.state = 102
                self.match(MiniCParser.T__1)
                self.state = 103
                self.statement()
                pass
            elif token in [14]:
                self.enterOuterAlt(localctx, 2)
                self.state = 105
                self.match(MiniCParser.T__13)
                self.state = 106
                self.match(MiniCParser.T__0)
                self.state = 108
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 3145730) != 0):
                    self.state = 107
                    self.expression()


                self.state = 110
                self.match(MiniCParser.T__4)
                self.state = 112
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 3145730) != 0):
                    self.state = 111
                    self.expression()


                self.state = 114
                self.match(MiniCParser.T__4)
                self.state = 116
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 3145730) != 0):
                    self.state = 115
                    self.expression()


                self.state = 118
                self.match(MiniCParser.T__1)
                self.state = 119
                self.statement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReturnStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(MiniCParser.ExpressionContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_returnStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturnStatement" ):
                listener.enterReturnStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturnStatement" ):
                listener.exitReturnStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReturnStatement" ):
                return visitor.visitReturnStatement(self)
            else:
                return visitor.visitChildren(self)




    def returnStatement(self):

        localctx = MiniCParser.ReturnStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_returnStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 122
            self.match(MiniCParser.T__14)
            self.state = 124
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 3145730) != 0):
                self.state = 123
                self.expression()


            self.state = 126
            self.match(MiniCParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(MiniCParser.ExpressionContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_expressionStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionStatement" ):
                listener.enterExpressionStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionStatement" ):
                listener.exitExpressionStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionStatement" ):
                return visitor.visitExpressionStatement(self)
            else:
                return visitor.visitChildren(self)




    def expressionStatement(self):

        localctx = MiniCParser.ExpressionStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_expressionStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 129
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 3145730) != 0):
                self.state = 128
                self.expression()


            self.state = 131
            self.match(MiniCParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assignmentExpression(self):
            return self.getTypedRuleContext(MiniCParser.AssignmentExpressionContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)




    def expression(self):

        localctx = MiniCParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.assignmentExpression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MiniCParser.ID, 0)

        def additiveExpression(self):
            return self.getTypedRuleContext(MiniCParser.AdditiveExpressionContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_assignmentExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignmentExpression" ):
                listener.enterAssignmentExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignmentExpression" ):
                listener.exitAssignmentExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignmentExpression" ):
                return visitor.visitAssignmentExpression(self)
            else:
                return visitor.visitChildren(self)




    def assignmentExpression(self):

        localctx = MiniCParser.AssignmentExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_assignmentExpression)
        try:
            self.state = 139
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 135
                self.match(MiniCParser.ID)
                self.state = 136
                self.match(MiniCParser.T__3)
                self.state = 137
                self.additiveExpression()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 138
                self.additiveExpression()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditiveExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def multiplicativeExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.MultiplicativeExpressionContext)
            else:
                return self.getTypedRuleContext(MiniCParser.MultiplicativeExpressionContext,i)


        def getRuleIndex(self):
            return MiniCParser.RULE_additiveExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdditiveExpression" ):
                listener.enterAdditiveExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdditiveExpression" ):
                listener.exitAdditiveExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdditiveExpression" ):
                return visitor.visitAdditiveExpression(self)
            else:
                return visitor.visitChildren(self)




    def additiveExpression(self):

        localctx = MiniCParser.AdditiveExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_additiveExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 141
            self.multiplicativeExpression()
            self.state = 146
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==16 or _la==17:
                self.state = 142
                _la = self._input.LA(1)
                if not(_la==16 or _la==17):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 143
                self.multiplicativeExpression()
                self.state = 148
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MultiplicativeExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primaryExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MiniCParser.PrimaryExpressionContext)
            else:
                return self.getTypedRuleContext(MiniCParser.PrimaryExpressionContext,i)


        def getRuleIndex(self):
            return MiniCParser.RULE_multiplicativeExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicativeExpression" ):
                listener.enterMultiplicativeExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicativeExpression" ):
                listener.exitMultiplicativeExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplicativeExpression" ):
                return visitor.visitMultiplicativeExpression(self)
            else:
                return visitor.visitChildren(self)




    def multiplicativeExpression(self):

        localctx = MiniCParser.MultiplicativeExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_multiplicativeExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 149
            self.primaryExpression()
            self.state = 154
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==18 or _la==19:
                self.state = 150
                _la = self._input.LA(1)
                if not(_la==18 or _la==19):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 151
                self.primaryExpression()
                self.state = 156
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MiniCParser.ID, 0)

        def INT(self):
            return self.getToken(MiniCParser.INT, 0)

        def expression(self):
            return self.getTypedRuleContext(MiniCParser.ExpressionContext,0)


        def getRuleIndex(self):
            return MiniCParser.RULE_primaryExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimaryExpression" ):
                listener.enterPrimaryExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimaryExpression" ):
                listener.exitPrimaryExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimaryExpression" ):
                return visitor.visitPrimaryExpression(self)
            else:
                return visitor.visitChildren(self)




    def primaryExpression(self):

        localctx = MiniCParser.PrimaryExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_primaryExpression)
        try:
            self.state = 163
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [20]:
                self.enterOuterAlt(localctx, 1)
                self.state = 157
                self.match(MiniCParser.ID)
                pass
            elif token in [21]:
                self.enterOuterAlt(localctx, 2)
                self.state = 158
                self.match(MiniCParser.INT)
                pass
            elif token in [1]:
                self.enterOuterAlt(localctx, 3)
                self.state = 159
                self.match(MiniCParser.T__0)
                self.state = 160
                self.expression()
                self.state = 161
                self.match(MiniCParser.T__1)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





