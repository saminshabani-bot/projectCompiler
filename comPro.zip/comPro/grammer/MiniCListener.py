# Generated from MiniC.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .MiniCParser import MiniCParser
else:
    from MiniCParser import MiniCParser

# This class defines a complete listener for a parse tree produced by MiniCParser.
class MiniCListener(ParseTreeListener):

    # Enter a parse tree produced by MiniCParser#program.
    def enterProgram(self, ctx:MiniCParser.ProgramContext):
        pass

    # Exit a parse tree produced by MiniCParser#program.
    def exitProgram(self, ctx:MiniCParser.ProgramContext):
        pass


    # Enter a parse tree produced by MiniCParser#functionDefinition.
    def enterFunctionDefinition(self, ctx:MiniCParser.FunctionDefinitionContext):
        pass

    # Exit a parse tree produced by MiniCParser#functionDefinition.
    def exitFunctionDefinition(self, ctx:MiniCParser.FunctionDefinitionContext):
        pass


    # Enter a parse tree produced by MiniCParser#parameterList.
    def enterParameterList(self, ctx:MiniCParser.ParameterListContext):
        pass

    # Exit a parse tree produced by MiniCParser#parameterList.
    def exitParameterList(self, ctx:MiniCParser.ParameterListContext):
        pass


    # Enter a parse tree produced by MiniCParser#parameter.
    def enterParameter(self, ctx:MiniCParser.ParameterContext):
        pass

    # Exit a parse tree produced by MiniCParser#parameter.
    def exitParameter(self, ctx:MiniCParser.ParameterContext):
        pass


    # Enter a parse tree produced by MiniCParser#declaration.
    def enterDeclaration(self, ctx:MiniCParser.DeclarationContext):
        pass

    # Exit a parse tree produced by MiniCParser#declaration.
    def exitDeclaration(self, ctx:MiniCParser.DeclarationContext):
        pass


    # Enter a parse tree produced by MiniCParser#type.
    def enterType(self, ctx:MiniCParser.TypeContext):
        pass

    # Exit a parse tree produced by MiniCParser#type.
    def exitType(self, ctx:MiniCParser.TypeContext):
        pass


    # Enter a parse tree produced by MiniCParser#compoundStatement.
    def enterCompoundStatement(self, ctx:MiniCParser.CompoundStatementContext):
        pass

    # Exit a parse tree produced by MiniCParser#compoundStatement.
    def exitCompoundStatement(self, ctx:MiniCParser.CompoundStatementContext):
        pass


    # Enter a parse tree produced by MiniCParser#statement.
    def enterStatement(self, ctx:MiniCParser.StatementContext):
        pass

    # Exit a parse tree produced by MiniCParser#statement.
    def exitStatement(self, ctx:MiniCParser.StatementContext):
        pass


    # Enter a parse tree produced by MiniCParser#selectionStatement.
    def enterSelectionStatement(self, ctx:MiniCParser.SelectionStatementContext):
        pass

    # Exit a parse tree produced by MiniCParser#selectionStatement.
    def exitSelectionStatement(self, ctx:MiniCParser.SelectionStatementContext):
        pass


    # Enter a parse tree produced by MiniCParser#iterationStatement.
    def enterIterationStatement(self, ctx:MiniCParser.IterationStatementContext):
        pass

    # Exit a parse tree produced by MiniCParser#iterationStatement.
    def exitIterationStatement(self, ctx:MiniCParser.IterationStatementContext):
        pass


    # Enter a parse tree produced by MiniCParser#returnStatement.
    def enterReturnStatement(self, ctx:MiniCParser.ReturnStatementContext):
        pass

    # Exit a parse tree produced by MiniCParser#returnStatement.
    def exitReturnStatement(self, ctx:MiniCParser.ReturnStatementContext):
        pass


    # Enter a parse tree produced by MiniCParser#expressionStatement.
    def enterExpressionStatement(self, ctx:MiniCParser.ExpressionStatementContext):
        pass

    # Exit a parse tree produced by MiniCParser#expressionStatement.
    def exitExpressionStatement(self, ctx:MiniCParser.ExpressionStatementContext):
        pass


    # Enter a parse tree produced by MiniCParser#expression.
    def enterExpression(self, ctx:MiniCParser.ExpressionContext):
        pass

    # Exit a parse tree produced by MiniCParser#expression.
    def exitExpression(self, ctx:MiniCParser.ExpressionContext):
        pass


    # Enter a parse tree produced by MiniCParser#assignmentExpression.
    def enterAssignmentExpression(self, ctx:MiniCParser.AssignmentExpressionContext):
        pass

    # Exit a parse tree produced by MiniCParser#assignmentExpression.
    def exitAssignmentExpression(self, ctx:MiniCParser.AssignmentExpressionContext):
        pass


    # Enter a parse tree produced by MiniCParser#additiveExpression.
    def enterAdditiveExpression(self, ctx:MiniCParser.AdditiveExpressionContext):
        pass

    # Exit a parse tree produced by MiniCParser#additiveExpression.
    def exitAdditiveExpression(self, ctx:MiniCParser.AdditiveExpressionContext):
        pass


    # Enter a parse tree produced by MiniCParser#multiplicativeExpression.
    def enterMultiplicativeExpression(self, ctx:MiniCParser.MultiplicativeExpressionContext):
        pass

    # Exit a parse tree produced by MiniCParser#multiplicativeExpression.
    def exitMultiplicativeExpression(self, ctx:MiniCParser.MultiplicativeExpressionContext):
        pass


    # Enter a parse tree produced by MiniCParser#primaryExpression.
    def enterPrimaryExpression(self, ctx:MiniCParser.PrimaryExpressionContext):
        pass

    # Exit a parse tree produced by MiniCParser#primaryExpression.
    def exitPrimaryExpression(self, ctx:MiniCParser.PrimaryExpressionContext):
        pass



del MiniCParser